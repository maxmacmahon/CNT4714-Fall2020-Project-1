
public class Inventory {

	public String itemId;
	public String title;
	double totalPrice;
	
	public Inventory(String itemId, String title, double totalPrice) {
		super();
		this.itemId = itemId;
		this.title = title;
		this.totalPrice = totalPrice;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public double getTotalPrice() {		
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	@Override
	public String toString() {
		String money = String.format("$%.2f", totalPrice);
		return "Information for item: " + itemId + " " + title + ", price = " + money + ".";
	}	
	public String price() {
		String money = String.format("$%.2f", totalPrice);
		return money;
	}
}