// James MacMahon
// Project 1 (Sept. 15)
// CNT 4714 Fall 2020

import javax.swing.*;
import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import java.util.Random;
import static javax.swing.JOptionPane.showMessageDialog;

public class Project1 {

	private JFrame frame;
	private JTextField textField4;
	private JTextField textField3;
	private JTextField textField2;
	private JTextField textField1;
	private JTextField textField0;	
	int counter = 0;
	double counters = 1;
	int buttonCounter = 1;
	Inventory lastItem = new Inventory(null, null, 0);
	Inventory currentItem = new Inventory(null, null, 0);	
	Inventory temp = new Inventory(null, null, 0);	
	String bigText[] = new String[50];

	//Launch the application (main)	 
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Project1 window = new Project1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		});
	}
	
	//Create the application.	 
	public Project1() {
		initialize();
	}
	
	// run through the file and look for certain item ID's
	public static Inventory scanFile(String id, String num) {
		
		File myFile = new File("inventory.txt");
		String item = "";
		Inventory emptyInv = new Inventory(null, null, 0);
		double singleItem = Double.parseDouble(num);
										
		try (Scanner in = new Scanner(myFile)){	
			
			while (in.hasNextLine()) {	
	            item = in.nextLine();
	            String itemInfo[] = item.split(",");	
	            
	            if(id.contentEquals(itemInfo[0])) {	 	            	
	            	double temp = Double.parseDouble(itemInfo[2]);	            		            	
	            	double finalPrice = temp * singleItem;
            		            	            	
	            	Inventory myInv = new Inventory(id, itemInfo[1], finalPrice);	           
	            		            		            	
	            	return myInv;
	            }     	
			}
			
			System.err.print("Error: Invalid item ID.");
        	//System.exit(-1);
        	return emptyInv;
		}
		catch (FileNotFoundException ex){
			
			System.err.print("Error 404: File Not Found.");
		}
		
		return null;
	}
		
	// Write to a file and print the subtotal 
	public void confirm() {
	
		String id = textField1.getText();
		String num = textField2.getText();
		
		// if its the not first item, set current item, and add the last item to get a final price
		if(counter > 0) {		
			currentItem = scanFile(id, num);	
			
			System.out.println(currentItem.price());
			double currentPrice = currentItem.getTotalPrice();
			double lastPrice = lastItem.getTotalPrice();
			double price = lastPrice + currentPrice;	

			Inventory manyItems = new Inventory(null, null, price);
			
			System.out.println("total is: " + manyItems.price());
			textField4.setText(manyItems.price());			
			
			bigText[counter] = textField3.getText();
			System.out.println(bigText[counter]);
			
			temp = currentItem;
			lastItem = temp;
			counter++;												
		}
		else {												
			currentItem = scanFile(id, num);
			
			System.out.println(currentItem.price());					
			textField4.setText(currentItem.price());
			
			bigText[counter] = textField3.getText();		
			System.out.println(bigText[counter]);
			
			temp = currentItem;
			lastItem = temp;
			counter++;
		}
	}
	
	// write to the transaction file without overwriting
	public void updateFile() {
		
		int maxNum = 10000;
		int minNum = 1;
		double myRandNum;
		
		myRandNum = Math.random() * (maxNum - minNum + 1) + minNum;
		myRandNum = Math.round(myRandNum);
		
		try {
			FileWriter transFile = new FileWriter("transactions.txt", true);
			BufferedWriter out = new BufferedWriter(transFile);
			
			out.write("Transaction #" + myRandNum + " Added on: " + new java.util.Date()+"\n");
				
			for(int i = 0; i < counter; i++)
				out.write(bigText[i] + "\n");
				
			out.write("\n");
			out.close();
			transFile.close();
											
			showMessageDialog(null, "Order submitted.\nSuccessfully wrote to the transaction file.");		    
		} 
		catch (IOException ex) {
			System.out.println("An error occurred.");
			ex.printStackTrace();
		}	
		
		return;
	}
		
	//Initialize the contents of the frame.
	private void initialize() {
		
		// declare variables (frame and text boxes)
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(64, 64, 64));
		frame.setBounds(100, 100, 1158, 348);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField4 = new JTextField();
		textField4.setColumns(10);
		textField4.setBounds(446, 180, 629, 29);
		frame.getContentPane().add(textField4);
		
		textField3 = new JTextField();
		textField3.setColumns(10);
		textField3.setBounds(446, 141, 629, 29);
		frame.getContentPane().add(textField3);
		
		textField2 = new JTextField();
		textField2.setColumns(10);
		textField2.setBounds(446, 102, 629, 29);
		frame.getContentPane().add(textField2);
		
		textField1 = new JTextField();
		textField1.setColumns(10);
		textField1.setBounds(446, 63, 629, 29);
		frame.getContentPane().add(textField1);
		
		textField0 = new JTextField();
		textField0.setColumns(10);
		textField0.setBounds(446, 24, 629, 29);
		frame.getContentPane().add(textField0);
		
		// All necessary buttons
		JButton pItem = new JButton("Process Item #" + buttonCounter);
		JButton cItem = new JButton("Confirm Item #" + buttonCounter);
		JButton nOrder = new JButton("New Order");
		JButton fOrder = new JButton("Finish Order");
		JButton vOrder = new JButton("View Order");
		JButton Exit = new JButton("Exit");
		
		// View the order	
		vOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {						
				
				showMessageDialog(null, bigText);
			}
		});
		vOrder.setBounds(409, 242, 136, 34);
		frame.getContentPane().add(vOrder);
		vOrder.setEnabled(false);
		
		// Finish Order		
		fOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				updateFile();
				
				fOrder.setEnabled(false);
			}
		});
		fOrder.setBounds(555, 242, 136, 34);
		frame.getContentPane().add(fOrder);
		fOrder.setEnabled(false);
		
		// Exits the app
		Exit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
		Exit.setBounds(847, 242, 136, 34);
		frame.getContentPane().add(Exit);
				
		// Confirm the item and add to transaction log
		cItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
								
				String exists = textField3.getText();	
				String numOfDifItems = textField0.getText();			// lets you process multiple items
				double temp = Double.parseDouble(numOfDifItems);
				
				// check if there's anything in the text field						
				if(exists.contains("null")) {
					showMessageDialog(null, "Item not found in file");
				}
				else
					showMessageDialog(null, "Item accepted. \nYou can check it with the view button");				

				confirm();
				
				// checks if number of different items and the current number of items processed are equal then enable/disable the button					
				if(temp == counters) { 
					pItem.setEnabled(false);
					textField0.setEnabled(false);
					textField1.setEnabled(false);
					textField2.setEnabled(false);	
					textField3.setEnabled(false);
					textField4.setEnabled(false);
				}
				else { 
					pItem.setEnabled(true);
					buttonCounter++;
				}
		
				counters++;
						
				// reset the text fields             																		
				textField1.setText("");
				textField2.setText("");
										
				fOrder.setEnabled(true);
				vOrder.setEnabled(true);
				cItem.setEnabled(false);
				
				// update the buttons after hitting confirm
				pItem.setText("Process Item #" + buttonCounter);				
				cItem.setText("Confirm Item #" + buttonCounter);			
			}
		});
		cItem.setBounds(263, 242, 136, 34);
		frame.getContentPane().add(cItem);
		cItem.setEnabled(false);
		
		// Processes an item and prints information		
		pItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {						 
											
				// enable/disable certain buttons
				pItem.setEnabled(false);
				cItem.setEnabled(true);
						
				Inventory myInv = new Inventory(null, null, 0);											
						
				try {	
										
					String id = textField1.getText();
					String numOfItem = textField2.getText();
												
					myInv = scanFile(id, numOfItem);					
																	
					textField3.setText(myInv.toString());															
				}
				catch(Exception exc) {
					System.err.print("Error processing item.");		
					return;
				}
					
				if(textField0.getText().equals("1"))
					pItem.setEnabled(false);
			}
		});			
		pItem.setBounds(117, 242, 136, 34);
		frame.getContentPane().add(pItem);

		// Resets the fields and makes a new order
		nOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				currentItem = new Inventory(null, null, 0);
				lastItem = new Inventory(null, null, 0);
				temp = new Inventory(null, null, 0);					
				bigText = new String[50];
						
				textField0.setText("");
				textField1.setText("");
				textField2.setText("");
				textField3.setText("");
				textField4.setText("");
						
				pItem.setEnabled(true);
				cItem.setEnabled(false);
				fOrder.setEnabled(false);
				vOrder.setEnabled(false);
				
				textField0.setEnabled(true);
				textField1.setEnabled(true);
				textField2.setEnabled(true);	
				textField3.setEnabled(true);
				textField4.setEnabled(true);
				
				// update the buttons after hitting new order
				buttonCounter = 1;
				counter = 0;
				counters = 1;
				pItem.setText("Process Item #" + buttonCounter);				
				cItem.setText("Confirm Item #" + buttonCounter);	
			}
		});
		nOrder.setBounds(701, 242, 136, 34);
		frame.getContentPane().add(nOrder);
							
////////////////////////////////////////////////////////////////////////////////////////////////////////////		
		// Labels for each of the text fields
		JLabel Label0 = new JLabel("Enter number of different items in the order");
		Label0.setForeground(Color.WHITE);
		Label0.setFont(new Font("Tahoma", Font.PLAIN, 20));
		Label0.setBounds(22, 24, 399, 29);
		frame.getContentPane().add(Label0);
		
		JLabel Label1 = new JLabel("Enter item ID");
		Label1.setForeground(Color.WHITE);
		Label1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		Label1.setBounds(285, 63, 136, 29);
		frame.getContentPane().add(Label1);
		
		JLabel Label2 = new JLabel("Enter quantity of a particular item");
		Label2.setForeground(Color.WHITE);
		Label2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		Label2.setBounds(102, 102, 310, 29);
		frame.getContentPane().add(Label2);
		
		JLabel Label3 = new JLabel("Item info");
		Label3.setForeground(Color.WHITE);
		Label3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		Label3.setBounds(319, 141, 117, 29);
		frame.getContentPane().add(Label3);
		
		JLabel Label4 = new JLabel("Order subtotal");
		Label4.setForeground(Color.WHITE);
		Label4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		Label4.setBounds(273, 180, 148, 29);
		frame.getContentPane().add(Label4);
	}
}
